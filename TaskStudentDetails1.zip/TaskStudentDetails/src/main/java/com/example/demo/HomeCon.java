package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class HomeCon {

	@Autowired
	StudService es;
	
	@RequestMapping("/")
	public String disp()
	{
		return "index";  // index.jsp
	}

	@PostMapping("/pen")
	public String get(@ModelAttribute("e1") Stud e1)
	{
		es.getdata(e1);
		return "redirect:/welcome";  
	}
	
	@RequestMapping("/welcome")
	public String display(ModelMap m)
	{
		List<Stud> sp=es.rd();
		m.addAttribute("sp",sp);
		return "welcome";  //welcome.jsp
	}
	
	@GetMapping("/deletestud")
	public String del(@RequestParam("id") int id)
	{
		es.deletedata(id);
		return "redirect:/welcome";
	}
	
	@GetMapping("/editstud")
	public String edit(@RequestParam("id")int id,ModelMap m)
	{
		Stud data=es.getonstud(id);
		m.addAttribute("data",data);
		return "edit";  //edit.jsp
	}
	
	
	
	@RequestMapping("/update")
	public String updatedata(@ModelAttribute("s1") Stud s1)
	{
		Stud e = new Stud();
		e.setId(s1.getId());
		e.setName(s1.getName());
		e.setEmail(s1.getEmail());
		e.setNumber(s1.getNumber());

		es.getdata(e);
		return "index";
	}
	
}