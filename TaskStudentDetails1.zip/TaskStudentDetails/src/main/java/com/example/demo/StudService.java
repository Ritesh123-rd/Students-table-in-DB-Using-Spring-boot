package com.example.demo;

import java.util.List;

public interface StudService {

	void getdata (Stud e);
	
	List<Stud> rd();
	
	void deletedata(int id);
	
	Stud getonstud(int id);
	
}
