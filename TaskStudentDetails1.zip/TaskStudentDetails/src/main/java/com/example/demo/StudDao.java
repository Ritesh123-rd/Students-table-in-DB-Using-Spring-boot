package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudDao implements StudService {

	@Autowired
	StudRepo er;
	@Override
	public void getdata(Stud e) {
		
		er.save(e);
	}
	@Override
	public List<Stud> rd() {

		return er.findAll();
	}
	@Override
	public void deletedata(int id) {

		er.deleteById(id);
	}
	@Override
	public Stud getonstud(int id) {

		Stud sp=er.getById(id);
		return sp;
		
	}

}
